# import os
# import subprocess

# # Jalankan Streamlit di port 8600 tanpa CORS/XSRF
# command = [
#     "streamlit", "run", "dashboard.py",
#     "--server.port=8600",
#     "--server.enableCORS=false",
#     "--server.enableXsrfProtection=false"
# ]

# # Jalankan sebagai proses baru
# subprocess.run(command)
